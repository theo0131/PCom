#include "helpers.h"
#include "nlohmann/json.hpp"
#include "requests.h"
#include <arpa/inet.h>
#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

using namespace std;

using json = nlohmann::json;

void register_req(int sockfd, char *username, char *password) {
  char *message;
  char *response;

  json reg_info =
      json::object({{"username", username}, {"password", password}});

  message = compute_post_request(
      (char *)"34.118.48.238", (char *)"/api/v1/tema/auth/register",
      (char *)"application/json", (char *)reg_info.dump().c_str(), NULL, 0);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);
  char *start = strstr(response, " ");
  char is_ok = start[1];
  if (is_ok == '2')
    printf("Register: success\n");
  else {
    char *error = strstr(response, "\"error\"");
    error[strlen(error) - 1] = '\0';
    printf("%s\n", error);
  }

  free(message);
  free(response);
}

char *login_req(int sockfd, char *username, char *password) {
  char *message;
  char *response;

  json reg_info =
      json::object({{"username", username}, {"password", password}});

  message = compute_post_request(
      (char *)"34.118.48.238", (char *)"/api/v1/tema/auth/login",
      (char *)"application/json", (char *)reg_info.dump().c_str(), NULL, 0);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);
  char *start = strstr(response, " ");
  char is_ok = start[1];
  if (is_ok == '2')
    printf("Login: success\n");
  else {
    char *error = strstr(response, "\"error\"");
    error[strlen(error) - 1] = '\0';
    printf("%s\n", error);
    return NULL;
  }
  char *cookie_start = strstr(response, "Set-Cookie:");
  char *cookie_end = strchr(cookie_start, ';');
  char *cookie = cookie_start + 12;
  cookie[cookie_end - cookie_start - 12] = '\0';

  free(message);
  free(response);

  return cookie;
}

char *access_req(int sockfd, char **cookies) {

  char *message;
  char *response;
  message = compute_get_request((char *)"34.118.48.238",
                                (char *)"/api/v1/tema/library/access", NULL,
                                cookies, 1);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);

  char *start = strstr(response, " ");
  char is_ok = start[1];
  if (is_ok == '2')
    printf("Enter library: success\n");
  else {
    char *error = strstr(response, "\"error\"");
    error[strlen(error) - 1] = '\0';
    printf("%s\n", error);
    return NULL;
  }

  char *token = strstr(response, "token");
  token = token + 8;
  token[strlen(token) - 2] = '\0';

  free(message);
  free(response);

  return token;
}

void get_books_req(int sockfd, char *token) {

  if (strlen(token) < 1) {
    printf("Please enter the library first\n");
    return;
  }

  char *message;
  char *response;
  message = compute_get_request_with_token((char *)"34.118.48.238",
                                           (char *)"/api/v1/tema/library/books",
                                           NULL, NULL, 0, token);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);

  char *start = strstr(response, "[");
  char end = start[1];
  if (end != ']')
    printf("%s\n", start);
  else
    printf("No books found\n");

  free(message);
  free(response);
}

void get_book_req(int sockfd, char *token, char *id) {

  if (strlen(token) < 1) {
    printf("Please enter the library first\n");
    return;
  }

  char *message;
  char *response;
  char *route = (char *)malloc(50 * sizeof(char));
  strcpy(route, "/api/v1/tema/library/books/");
  strcat(route, id);
  message = compute_get_request_with_token((char *)"34.118.48.238", route, NULL,
                                           NULL, 0, token);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);

  char *start = strstr(response, " ");
  char is_ok = start[1];
  if (is_ok == '2') {
    char *book = strstr(response, "[");
    printf("%s\n", book);
  } else {
    char *error = strstr(response, "\"error\"");
    error[strlen(error) - 1] = '\0';
    printf("%s\n", error);
  }

  free(message);
  free(response);
}

void add_book_req(int sockfd, char *title, char *author, char *genre, int count,
                  char *publisher, char *token) {

  if (strlen(token) < 1) {
    printf("Please enter the library first\n");
    return;
  }

  char *message;
  char *response;

  json reg_info = json::object({{"title", title},
                                {"author", author},
                                {"genre", genre},
                                {"page_count", count},
                                {"publisher", publisher}});

  message = compute_post_request_with_token(
      (char *)"34.118.48.238", (char *)"/api/v1/tema/library/books",
      (char *)"application/json", (char *)reg_info.dump().c_str(), NULL, 0,
      token);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);
  char *start = strstr(response, " ");
  char is_ok = start[1];
  if (is_ok == '2')
    printf("Add_book: success\n");
  else if (is_ok == '5') {
    char *error = strstr(response, "\"error\"");
    error[strlen(error) - 1] = '\0';
    printf("%s\n", error);
  } else
    printf("%s\n", response);

  free(message);
  free(response);
}

void delete_book(int sockfd, char *token, char *id) {

  if (strlen(token) < 1) {
    printf("Please enter the library first\n");
    return;
  }

  char *message;
  char *response;
  char *route = (char *)malloc(50 * sizeof(char));
  strcpy(route, "/api/v1/tema/library/books/");
  strcat(route, id);
  message = compute_delete_request_with_token((char *)"34.118.48.238", route,
                                              NULL, NULL, 0, token);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);
  char *start = strstr(response, " ");
  char is_ok = start[1];
  if (is_ok == '2')
    printf("Delete_book: success\n");
  else {
    char *error = strstr(response, "\"error\"");
    error[strlen(error) - 1] = '\0';
    printf("%s\n", error);
  }

  free(message);
  free(response);
}

void logout_req(int sockfd, char **cookies) {

  char *message;
  char *response;
  message =
      compute_get_request((char *)"34.118.48.238",
                          (char *)"/api/v1/tema/auth/logout", NULL, cookies, 1);

  send_to_server(sockfd, message);
  response = receive_from_server(sockfd);

  char *start = strstr(response, " ");
  char is_ok = start[1];
  if (is_ok == '2')
    printf("Logout: success\n");
  else {
    char *error = strstr(response, "\"error\"");
    error[strlen(error) - 1] = '\0';
    printf("%s\n", error);
  }

  free(message);
  free(response);
}

int main(int argc, char *argv[]) {
  int sockfd;
  char *session_cookie = (char *)calloc(200, sizeof(char));
  char *session_token = (char *)calloc(200, sizeof(char));

  int is_exit = 0;

  while (!is_exit) {
    sockfd =
        open_connection((char *)"34.118.48.238", 8080, AF_INET, SOCK_STREAM, 0);
    char *command = (char *)malloc(15 * sizeof(char));
    cin >> command;
    if (strcmp(command, "exit") == 0) {
      is_exit = 1;
    } else if (strcmp(command, "register") == 0) {
      char *username = (char *)malloc(20 * sizeof(char));
      char *password = (char *)malloc(20 * sizeof(char));
      cout << "username=";
      cin >> username;
      cout << "password=";
      cin >> password;
      register_req(sockfd, username, password);
    } else if (strcmp(command, "login") == 0) {
      char *username = (char *)malloc(20 * sizeof(char));
      char *password = (char *)malloc(20 * sizeof(char));
      cout << "username=";
      cin >> username;
      cout << "password=";
      cin >> password;
      session_cookie = login_req(sockfd, username, password);
    } else if (strcmp(command, "enter_library") == 0) {
      char *cookies[1];
      cookies[0] = session_cookie;
      session_token = access_req(sockfd, cookies);
    } else if (strcmp(command, "get_books") == 0) {
      get_books_req(sockfd, session_token);
    } else if (strcmp(command, "get_book") == 0) {
      char *id = (char *)malloc(20 * sizeof(char));
      cout << "id=";
      cin >> id;
      get_book_req(sockfd, session_token, id);
    } else if (strcmp(command, "add_book") == 0) {
      char *title = (char *)malloc(50 * sizeof(char));
      char *author = (char *)malloc(50 * sizeof(char));
      char *genre = (char *)malloc(50 * sizeof(char));
      char *publisher = (char *)malloc(50 * sizeof(char));
      char *page_count = (char *)malloc(5 * sizeof(char));
      cout << "title=";
      cin >> title;
      cout << "author=";
      cin >> author;
      cout << "genre=";
      cin >> genre;
      cout << "publisher=";
      cin >> publisher;
      cout << "page_count=";
      cin >> page_count;
      add_book_req(sockfd, title, author, genre, atoi(page_count), publisher,
                   session_token);
    } else if (strcmp(command, "logout") == 0) {
      char *cookies[1];
      cookies[0] = session_cookie;
      logout_req(sockfd, cookies);
    } else if (strcmp(command, "delete_book") == 0) {
      char *id = (char *)malloc(20 * sizeof(char));
      cout << "id=";
      cin >> id;
      delete_book(sockfd, session_token, id);
    }
  }
  close_connection(sockfd);

  return 0;
}