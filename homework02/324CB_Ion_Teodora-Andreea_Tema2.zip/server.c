#include <arpa/inet.h>
#include <math.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include "helpers.h"
#include "queue.h"

void usage(char *file) {
  fprintf(stderr, "Usage: %s server_port\n", file);
  exit(0);
}

int main(int argc, char *argv[]) {
  setvbuf(stdout, NULL, _IONBF, BUFSIZ);
  int sockfd_tcp, newsockfd_tcp, sockfd_udp, portno;
  char buffer[BUFLEN];
  struct sockaddr_in taddr, uaddr, cli_addr;
  int n, i, ret;
  socklen_t clilen;
  unsigned int *len_sockaddr = malloc(sizeof(unsigned int));
  int flag = 1;
  int is_exit = 0;

  // initialize the queue that will store the offline clients
  queue clients_offline = queue_create();

  // initialize the queue that will store the online clients
  queue clients_online = queue_create();

  fd_set read_fds;
  fd_set tmp_fds;
  int fdmax;

  if (argc < 2) {
    usage(argv[0]);
  }

  FD_ZERO(&read_fds);
  FD_ZERO(&tmp_fds);

  // udp socket
  sockfd_udp = socket(PF_INET, SOCK_DGRAM, 0);
  DIE(sockfd_udp == -1, "socket udp");

  // tcp socket
  sockfd_tcp = socket(AF_INET, SOCK_STREAM, 0);
  DIE(sockfd_tcp < 0, "socket tcp");

  // port for server
  portno = atoi(argv[1]);
  DIE(portno == 0, "atoi");

  memset((char *)&taddr, 0, sizeof(taddr));
  memset((char *)&uaddr, 0, sizeof(uaddr));

  // tcp sockaddr_in
  taddr.sin_family = AF_INET;
  taddr.sin_port = htons(portno);
  taddr.sin_addr.s_addr = INADDR_ANY;

  // udp sockaddr_in
  uaddr.sin_family = AF_INET;
  uaddr.sin_port = htons(portno);
  uaddr.sin_addr.s_addr = INADDR_ANY;

  ret = bind(sockfd_tcp, (struct sockaddr *)&taddr, sizeof(struct sockaddr));
  DIE(ret < 0, "bind tcp");

  ret = bind(sockfd_udp, (struct sockaddr *)&uaddr, sizeof(struct sockaddr));
  DIE(ret < 0, "bind udp");

  ret = listen(sockfd_tcp, MAX_CLIENTS);
  DIE(ret < 0, "listen");

  FD_SET(sockfd_tcp, &read_fds);
  FD_SET(sockfd_udp, &read_fds);
  FD_SET(0, &read_fds);
  fdmax = sockfd_tcp;

  // as long as it is not given an exit command from keyboard
  while (!is_exit) {
    tmp_fds = read_fds;

    // set the buffer where the messages will be received
    memset(buffer, 0, BUFLEN);
    ret = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
    DIE(ret < 0, "select");

    // for each fd
    for (i = 0; i <= fdmax; i++) {
      if (FD_ISSET(i, &tmp_fds)) {
        if (i == 0) {
          memset(buffer, 0, BUFLEN);

          // read from stdin the given command
          fgets(buffer, BUFLEN - 1, stdin);
          if (strcmp(buffer, "exit\n") == 0) {

            // if it is exit, close the server
            send(sockfd_tcp, "exit", 4, 0);
            is_exit = 1;
            break;
          }
        }
        // if it is the udp sockfd
        else if (i == sockfd_udp) {

          // receive the message sent from udp client
          ret = recvfrom(sockfd_udp, buffer, BUFLEN, 0,
                         (struct sockaddr *)(&uaddr), len_sockaddr);
          DIE(ret < 0, "recv udp msg");

          // if the number if bytes sent are 0, close the socket
          if (ret == 0) {
            close(i);
            FD_CLR(i, &read_fds);
            // else it is a message to be sent to tcp clients
          } else {
            // create and complete the message to be sent to tcp client
            // with the information from udp message
            struct msg_to_send msg_tcp;
            strcpy(msg_tcp.ip_udp, inet_ntoa(uaddr.sin_addr));
            msg_tcp.port_udp = ntohs(uaddr.sin_port);

            struct msg_from_udp *msg = (struct msg_from_udp *)buffer;
            complete_tcp_msg(msg, &msg_tcp);

            // send the message to the online clients
            // that are subscribed to the topic
            clients_online = send_msg(clients_online, msg_tcp);

            // add the message to the list of unsent messages
            // for the offline clients that are subscribed to the topic
            clients_offline = add_msg_to_queue(clients_offline, &msg_tcp);
          }
        }
        // if it is the tcp socket
        else if (i == sockfd_tcp) {

          clilen = sizeof(cli_addr);
          newsockfd_tcp =
              accept(sockfd_tcp, (struct sockaddr *)&cli_addr, &clilen);
          DIE(newsockfd_tcp < 0, "accept");

          setsockopt(newsockfd_tcp, IPPROTO_TCP, TCP_NODELAY, (char *)&flag,
                     sizeof(int));

          FD_SET(newsockfd_tcp, &read_fds);
          if (newsockfd_tcp > fdmax) {
            fdmax = newsockfd_tcp;
          }
          // set the buffer and receive the message from tcp client
          memset(buffer, 0, BUFLEN);
          ret = recv(newsockfd_tcp, buffer, sizeof(buffer), 0);
          DIE(ret < 0, "recv id");

          // create a new client
          struct client *cl = malloc(sizeof(struct client));
          sprintf(cl->id, "%s", buffer);
          cl->sockfd = newsockfd_tcp;
          cl->unsent = queue_create();
          cl->topics = queue_create();

          struct client *found = (struct client *)malloc(sizeof(struct client));
          strcpy(found->id, "NON");
          int deleted = 0;
          // delete the client from the offline queue
          // if previously connected
          clients_offline =
              del_client(clients_offline, buffer, found, &deleted);
          // if it has unsent messages
          if (deleted != 0) {
            found->sockfd = newsockfd_tcp;

            // send all the messages to the tcp client
            while (!queue_empty(found->unsent)) {
              struct msg_to_send *tcp_msg_aux = queue_deq(found->unsent);
              send(found->sockfd, (char *)tcp_msg_aux,
                   sizeof(struct msg_to_send), 0);
            }
            // add the client to the online queue and announce it
            queue_enq(clients_online, found);
            printf("New client %s connected from %s:%hu.\n", buffer,
                   inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
            continue;
          }
          // if the tcp client was previously connected
          // but with no unsent messages
          if (strcmp(found->id, buffer) == 0) {
            queue_enq(clients_online, found);
            printf("New client %s connected from %s:%hu.\n", buffer,
                   inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
            continue;
          }
          // check if the tcp client already exists in the online queue
          int check = 0;
          clients_online = already_in_list(clients_online, buffer, &check);
          if (check == 0)
            queue_enq(clients_online, cl);
          else {
            printf("Client %s already connected.\n", cl->id);
            send(newsockfd_tcp, "exit", 4, 0);
            close(newsockfd_tcp);
            FD_CLR(newsockfd_tcp, &read_fds);
            continue;
          }
          printf("New client %s connected from %s:%hu.\n", buffer,
                 inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));

        } else {
          memset(buffer, 0, BUFLEN);
          n = recv(i, buffer, sizeof(buffer), 0);
          DIE(n < 0, "recv");
          // if the number of bytes receives is 0
          if (n == 0) {
            char id[11];
            memset(id, 0, 11);
            sprintf(id, "%s", "NON");
            int deleted = 0;
            int ok = 0;
            clients_online = find_client(clients_online, i, id, &ok);

            // disconnect the client, delete it from online queue
            // and add it to the offline queue
            if (strcmp(id, "NON") != 0 && ok == 1) {
              printf("Client %s disconnected.\n", id);
              struct client *found =
                  (struct client *)malloc(sizeof(struct client));
              clients_online = del_client(clients_online, id, found, &deleted);
              queue_enq(clients_offline, found);

              close(i);
              FD_CLR(i, &read_fds);
            }
            // else it is a subscribe or unsubscribe request
          } else {
            struct msg_from_tcp *msg = (struct msg_from_tcp *)buffer;
            if (msg->type == 1)
              clients_online = subscribe(msg, i, clients_online);
            else
              clients_online = unsubscribe(msg, i, clients_online);
          }
        }
      }
    }
  }

  // close sockets
  for (i = 0; i <= fdmax; i++) {

    if (FD_ISSET(i, &tmp_fds)) {
      close(i);
    }
  }

  return 0;
}