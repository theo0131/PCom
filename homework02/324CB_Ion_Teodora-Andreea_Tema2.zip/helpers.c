#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "helpers.h"
#include "queue.h"


/* Function that subscribes the client with the given sockfd
 to the topic contained in the message from tcp client */
queue subscribe(struct msg_from_tcp *msg, int sockfd, queue clients) {
	struct topic *topic = malloc(sizeof(struct topic));
	sprintf(topic->name, "%s", msg->topic);
	topic->sf = msg->sf;
	queue aux = queue_create();
	while (!queue_empty(clients)) {
		struct client *cl = queue_deq(clients);
		if (cl->sockfd == sockfd) {
			queue_enq(cl->topics, topic);
		}
		queue_enq(aux, cl);
	}
	return aux;
}

/* Function that unsubscribes the client with the given sockfd
 from the topic contained in the message from tcp client */
queue unsubscribe(struct msg_from_tcp *msg, int sockfd, queue clients) {
	char *copy = malloc((strlen(msg->topic)-1)*sizeof(char));
	memcpy(copy, msg->topic, strlen(msg->topic)-1);
	queue aux = queue_create();
	while (!queue_empty(clients)) {
		struct client *cl = queue_deq(clients);
		if (cl->sockfd == sockfd) {
			queue tmp = queue_create();
			while (!queue_empty(cl->topics)) {
				struct topic *topic = queue_deq(cl->topics);
				if (strcmp(topic->name, copy) != 0)
					queue_enq(tmp, topic);
			}
			cl->topics = tmp;
		}
		queue_enq(aux, cl);
	}
	return aux;
}

/* Function that searches the client with the given sockfd
 and saves its id if found */
queue find_client(queue clients, int sockfd, char* id, int *found) {
	queue aux = queue_create();
	while (!queue_empty(clients)) {
		struct client *cl = queue_deq(clients);
		if (cl->sockfd == sockfd)
		{
			sprintf(id, "%s", cl->id);
			*found = 1;
		}
		queue_enq(aux, cl);
	}
	return aux;
}

/* Function that checks if the client
 with the given id exists in the given queue */
queue already_in_list(queue clients, char* id, int *ok) {
	queue aux = queue_create();
	while (!queue_empty(clients)) {
		struct client *cl = queue_deq(clients);
		if(strcmp(id, cl->id) == 0) {
			*ok = 1;
		}
		queue_enq(aux, cl);
	}
	return aux;
}

/* Function that deletes the client with the given id from queue
	Saves the deleted client into the variable found
	"deleted" marks if there are messages to be sent afterward */
queue del_client(queue clients, char* id, struct client *found, int *deleted) {
	queue aux = queue_create();
	while (!queue_empty(clients)) {
		struct client *cl = queue_deq(clients);
		if (strcmp(cl->id, id) != 0)
			queue_enq(aux, cl);
		else {
			memcpy(found->id, cl->id, sizeof(cl->id));
			found->sockfd = cl->sockfd;
			found->topics = queue_create();
			
			while (cl->topics != NULL && !queue_empty(cl->topics)) {
				struct topic *top = queue_deq(cl->topics);
				queue_enq(found->topics, top);
			}
			
			found->unsent = queue_create();
			while (cl->unsent != NULL && !queue_empty(cl->unsent)) {
				*deleted = 1;
				struct msg_to_send *msg = queue_deq(cl->unsent);
				queue_enq(found->unsent, msg);
			}
		}
	}

	return aux;
}

/* Function that completes a message that has to be sent to a tcp client */
void complete_tcp_msg (struct msg_from_udp *msg, struct msg_to_send *tcp_msg) {

	// Copy the topic
	sprintf(tcp_msg->topic, "%s", msg->topic);

	// Complete type attribute according to its type
	if (msg->type == 0) {
		sprintf(tcp_msg->type, "INT");
	}
	else if (msg->type == 1) {
		sprintf(tcp_msg->type, "SHORT_REAL");
	}
	else if (msg->type == 2) {
		sprintf(tcp_msg->type, "FLOAT");
	}
	else if (msg->type == 3) {
		sprintf(tcp_msg->type, "STRING");
	}

	// Complete the payload that will be interpreted when printing
	memcpy(tcp_msg->payload, msg->payload, PAYLOADLEN);
}

/* Funtion that prints a tcp message payload given in the buffer 
 according to the data type */
void print_msg(struct msg_to_send *tcp_msg, char *buffer) {

	// The payload contains an INT
	if (strcmp(tcp_msg->type, "INT") == 0) {
		uint32_t payload = ntohl(*(uint32_t*)(buffer + 1));
		if (buffer[0] == 1)
			printf("-%u\n", payload);
		else
			printf("%u\n", payload);
	}

	// The payload contains a SHORT_REAL
	else if (strcmp(tcp_msg->type, "SHORT_REAL") == 0) {
		double payload = ntohs(*(uint16_t*)(buffer));
		payload /= 100;
		unsigned int as_int = (unsigned int)payload;
		if (as_int == payload)
			printf("%u\n", as_int);
		else
			printf("%.2f\n", (double)payload);
	}

	// The payload contains a FLOAT
	else if (strcmp(tcp_msg->type, "FLOAT") == 0) {
		double payload = ntohl(*(uint32_t*)(buffer + 1));
        payload /= pow(10, buffer[5]);

        if (buffer[0] == 1) {
            printf("-%.*f\n", buffer[5], (double)payload);
        }
        else
        	printf("%.*f\n", buffer[5], (double)payload);
	}

	// The payload contains a STRING
	else {
		printf("%s\n", buffer);
	}
}

/* Function that checks if the given client is subscribed to the given topic 
	Returns in ok if the client is subscribed or not
	and the sf for the topic in sf parameter */
queue is_subscribed(struct client *cl, char *topic, int *ok, int *sf) {
	queue tmp = queue_create();
	while (!queue_empty(cl->topics)) {
		struct topic *top = queue_deq(cl->topics);
		if (strcmp(top->name, topic) == 0) {
			*ok = 1;
			*sf = top->sf;
		}
		queue_enq(tmp, top);
	}
	
	return tmp;
}

/* Function that sends the given message
 to the tcp clients that are subscribed to the topic */
queue send_msg(queue clients, struct msg_to_send tcp_msg) {
	queue aux = queue_create();
	while (!queue_empty(clients)) {
		struct client *cl = queue_deq(clients);
		int ok = 0; int sf = 0;
		cl->topics = is_subscribed(cl, tcp_msg.topic, &ok, &sf);
		if (ok == 1) {
			send(cl->sockfd, (char*)&tcp_msg, sizeof(struct msg_to_send), 0);
		}
		queue_enq(aux, cl);
	}
	return aux;
}

/* Function that adds a message to the queue of unsent messages
 for the clients subscribed to the topic with sf when offline */
queue add_msg_to_queue(queue clients, struct msg_to_send *tcp_msg) {
	queue aux = queue_create();
	while (!queue_empty(clients)) {
		struct client *cl = queue_deq(clients);
		int ok = 0; int sf = 0;
		cl->topics = is_subscribed(cl, tcp_msg->topic, &ok, &sf);
		if (ok == 1 && sf == 1) {
			struct msg_to_send *copy = malloc(sizeof(struct msg_to_send));
			memcpy(copy, tcp_msg, sizeof(struct msg_to_send));
			queue_enq(cl->unsent, copy);
		}
		queue_enq(aux, cl);
	}

	return aux;
}