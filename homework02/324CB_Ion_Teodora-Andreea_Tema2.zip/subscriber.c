#include <arpa/inet.h>
#include <math.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include "helpers.h"
#include "queue.h"

void usage(char *file) {
  fprintf(stderr, "Usage: %s id_client server_address server_port\n", file);
  exit(0);
}

int main(int argc, char *argv[]) {
  setvbuf(stdout, NULL, _IONBF, BUFSIZ);
  int sockfd, n, ret, flag = 1;
  struct sockaddr_in serv_addr;
  char buffer[BUFLEN];

  if (argc != 4) {
    usage(argv[0]);
  }

  // create socket
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  DIE(sockfd < 0, "socket");

  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(atoi(argv[3]));
  ret = inet_aton(argv[2], &serv_addr.sin_addr);
  DIE(ret == 0, "inet_aton");

  // connect to the server
  ret = connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
  DIE(ret < 0, "connect");

  // send the id
  ret = send(sockfd, argv[1], strlen(argv[1]) + 1, 0);
  DIE(ret < 0, "send id");

  fd_set set, temp;
  int fdmax = sockfd;

  setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(int));

  FD_ZERO(&set);
  FD_ZERO(&temp);

  FD_SET(STDIN_FILENO, &set);
  FD_SET(sockfd, &set);

  // as long as an exit command is received
  while (1) {
    temp = set;
    ret = select(fdmax + 1, &temp, NULL, NULL, NULL);

    if (FD_ISSET(STDIN_FILENO, &temp)) {
      // read from stdin
      memset(buffer, 0, BUFLEN);
      fgets(buffer, BUFLEN - 1, stdin);
      if (strncmp(buffer, "exit", 4) == 0) {
        break;
      }

      // create a message structure that will be sent to server
      struct msg_from_tcp msg;
      int type = 0;
      char *token;
      token = strtok(buffer, " ");

      // annalize the command received from keyboard
      // can be a subscribe or unsubscribe command
      if (token != NULL && strcmp(token, "subscribe") == 0) {
        type = 1;

        token = strtok(NULL, " ");
        sprintf(msg.topic, "%s", token);
        msg.topic[51] = '\0';
        msg.type = 1;
        token = strtok(NULL, " ");
        uint8_t sf = atoi(token);
        msg.sf = sf;
      } else if (token != NULL && strcmp(token, "unsubscribe") == 0) {
        token = strtok(NULL, " ");
        sprintf(msg.topic, "%s", token);
        msg.type = 0;
        msg.sf = 0;
      }

      // send the message to the server
      n = send(sockfd, (char *)&msg, sizeof(msg), 0);
      DIE(n < 0, "send");

      if (type == 1)
        printf("Subscribed to topic.\n");
      else
        printf("Unsubscribed from topic.\n");
    }

    if (FD_ISSET(sockfd, &temp)) {

      memset(buffer, 0, BUFLEN);
      // if it is a message received (from server)
      int bytes_received = recv(sockfd, buffer, sizeof(struct msg_to_send), 0);
      DIE(bytes_received < 0, "eroare la receptie");

      if (bytes_received == 0)
        break;
      // check if it is an exit command
      if (strcmp(buffer, "exit") == 0)
        break;
      // if not, it is a message from a topic
      struct msg_to_send *tcp_msg = (struct msg_to_send *)buffer;
      // print the message
      printf("%s:%hu - %s - %s - ", tcp_msg->ip_udp, tcp_msg->port_udp,
             tcp_msg->topic, tcp_msg->type);
      print_msg(tcp_msg, tcp_msg->payload);
    }
  }
  // close socket
  close(sockfd);
  return 0;
}