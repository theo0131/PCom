Ion Teodora-Andreea
Group: 324CB

The purpose of this project is to create an application client-server.
The application implements protocols over TCP and UDP.

The data structures used to define the functionality of the protocols are:

 - msg_from_udp: - defines the messages received from an udp client
 				 - has as attributes: - topic (the name of the topic 
 				 where the data is published)
 				 			- type (data type = 0/1/2/3 
 				 that represents a specific type)
 				 			- payload (data received for publishing)
 
 - msg_from_tcp: - defines the messages received from a tcp client
 				 - has as attributes: - topic (the name of the topic)
 				 			- type (0 for unsubscribe, 1 for subscribe)
 				 			- sf (sf for the given topic)
 
 - msg_to_send: - defines the message to be sent to a tcp client
 				- has as attributes: - topic (topic name)
 							- type (INT/STRING/FLOAT/SHORT_REAL)
 							- payload (data to be sent)
 							- ip_udp (ip of the udp client 
 					that pusblished the data)
 							- port_udp (port of the udp client 
 					that pusblished the data)
 
 - client: - defines a tcp client
 		   - has as attributes: - id (the unique client id)
 		   						- sockfd (the socket 
 		   			where the client is connected)
 		   						- unsent (queue that keeps the unsent 
 		   			messages that are published while the client is offline)
 		   						- topics (queue that keeps the topics a client
 		   			is subscribed to)
 
 - topic: - defines a topic where a message is published
 		  - the structure is specific for each client
 		  - has as attributes: - name (topic name)
 		  					   - sf (specific for each client)


The file helpers.c contains functions used to implement the protocols.
These functions are used in the server as well as in the subscriber.

 - subscribe: - subscribes the client with the given sockfd
 		to the topic that is specified by the message from tcp client
 		- to subscribe the client, the topic is added in the topics queue 
 		for that client
 		- returns the modified queue of clients

 - unsubscribe: - unsubscribes the client with the given sockfd
 		from the topic that is specified by the message from tcp client
 		- to unsubscribe the client, the given topic is deleted
 		from the queue of topics of that client

 - find_client: - searches in the queue the client that has the given sockfd
 				- returns its id in the id parameter

 - already_in_list: - checks if the client with the given id exists 
 			in the given queue of clients
 			- the parameter ok becomes 1 if the client is found
 
 - del_client: - deletes the client with the given id from given queue
 			   - returns the deleted client in the "found" parameter
 			   - deleted becomes 1 if the client has unsent messages
 
 - complete_tcp_msg: - ompletes a message that has to be sent to a tcp client
 					 - completes the type field
 					 - copies the received topic and the payload
 
 - print_msg: - interprets the payload of the given message after the type
 			  - prints the payload according to the interpretation
 
 - is_subscribed: - checks if the given client is subscribed to the given topic
 				  - ok becomes 1 if the client is subscribed
 				  - sf returns the topic sf specific for that client
 
 - send_msg: - sends the given message to the tcp clients subscribed
 		to the topic given in the message

 - add_msg_to_queue: - adds a message to the queue of unsent messages
 		of the clients subscribed to the topic given in the message
 		-the message is added to the unsent queue only if sf for the topic is 1
 		- the messages in unsent queue will be sent to the client 
 		when it will be online again


The server is the broker in the relation between udp and tcp clients.
The messages published by the udp are sent to and manages by the server.
The server sets a socket for tcp and one for udp.
The main functionality of the server is represented by:

 - if the socket is the 0 one, the server has received a command from stdin
 - if the command is represented by exit, the application stops,
 		the server sends close command to the subscribers and close the sockets

 - if the socket is the udp socket, read the message sent by udp client
 - if the number of bytes received is 0, 
 		close the connection with the udp client
 - else, the message received is a message to publish data at a topic
 - creates a msg_to_send structure to send the message to tcp clients
 - completes the fields of the structure with the information from udp message
 - sends the message to the online clients that are subscribed to the topic
 - adds the message to the unsent messages queue for the offline clients
 - the message is added to the unsent queue only if sf for that topic is 1

 - if the socket is the tcp socket, interprets the message sent from tcp client
 - if it is connection request, accepts
 - creates a new client with the given infromation
 - if the client was previously connected, deletes it from the offline queue
 - if there are any unsent messages received while the client was offline,
 		sends them
 - checks if the client requesting the connection has the same id
 		with another online client
 - if yes, closes the requesting client and prints a corresponding message
 - otherwise, adds the client to the online clients queue
 		and print to announce a new client
 - if the number of received bytes is 0, it means the client disconnected
 		and the server closes the socket for its connection
 - otherwise, it is a subscribe or unsubscribe request
 - if it is a subscribe request, subscribe the client to the given topic
 		with the given sf
 - if it is an unsubscribe request, unsubscribe the client from the given topic

 - when the server receives from keyboard the exit command, 
 		closes all the defined sockets


The subscriber is represented by a tcp client with a continous functionality.
After the connection to the server, as long as the exit command is not given,
		the tcp client can receive and send messages.
 - if a command is given from keyboard, reads it into e buffer from stdin

 - if the command is a subscribe request, creates a msg_from_tcp message
 - completes the fields with the topic and the sf given in the command
 - sets the type to 1 that signifies it is a subscribe request

 - if the command is an unsubscribe request, creates a msg_from_tcp
 - completes the topic with the one given in the command
 - sets the type to 0 beacause is an unsubscribe request
 - sets the sf attribute to 0 (it does not matter, it is not used)
 - sends the request to the server and prints a corresponding message

 - if the command is represented by exit, 
 		the server orders the closing of the tcp client
 - in this case, stop the subscriber and close the socket used for connection

 - else,it is a message published at a certain topic the client is subscribe to
 - print the message in a specified form according to the data type

 - at the end of program, close automatically the socket


In the implementation of the protocols, there are used queues to store 
multiple elements with a specific common element.
The structure of the queue is defined in the queue.h file.
The file queue.c contains the main functions that implements
the caracteristics of the queue:
 
 - queue_create: creates and returns an empty queue
 - queue_empty: checks if the queue is empty
 - queue_enq: adds an element at the end of the queue
 - queue_deq: extracts and returns the first inserated element in queue

To implement the queue structure it is used a list structure 
defined in list.h and list.c files.