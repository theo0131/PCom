#ifndef _HELPERS_H
#define _HELPERS_H 1

#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

/*
 * Macro de verificare a erorilor
 * Exemplu:
 *     int fd = open(file_name, O_RDONLY);
 *     DIE(fd == -1, "open failed");
 */

#define DIE(assertion, call_description)	\
	do {									\
		if (assertion) {					\
			fprintf(stderr, "(%s, %d): ",	\
					__FILE__, __LINE__);	\
			perror(call_description);		\
			exit(EXIT_FAILURE);				\
		}									\
	} while(0)

// Structure for a message received from an udp client
struct msg_from_udp{
    char topic[50];
    uint8_t type;
    char payload[1501];
};

// Structure for a message received from a tcp client
struct msg_from_tcp {
	// name of the topic to subscribe to or unsubscribe from
	char topic[51];

	// type is 1 for a subscribe message and 0 for unsubscribe
	uint8_t type;

	// the sf for the given topic in case of subscribe
	uint8_t sf;
};

// Structure for the message that has to be sent to a tcp client
struct msg_to_send {
	char topic[51];        // topic name
	char type[15];         // INT/STRING/FLOAT/SHORT_REAL
	char payload[1501];    // data to be sent
	char ip_udp[16];       // udp client ip
	uint16_t port_udp;     // udp client port
};

// Structure for a tcp client
struct client {
	char id[11];    // client id
	int sockfd;     // client sockfd
	queue unsent;   // unsent messages while offline
	queue topics;   // topics the client is subscribed to
};

// Structure for a topic
struct topic {
	char name[51];   // topic name
	uint8_t sf;      // sf for the client that has the topic in the list
};

#define BUFLEN		1600	// max length of the buffer
#define PAYLOADLEN  1501	// max length of the payload
#define MAX_CLIENTS	5		// max number of wainting clients

queue subscribe(struct msg_from_tcp *msg, int sockfd, queue clients);
queue unsubscribe(struct msg_from_tcp *msg, int sockfd, queue clients);
queue find_client(queue clients, int sockfd, char* id, int *found);
queue already_in_list(queue clients, char* id, int *ok);
queue del_client(queue clients, char* id, struct client *found, int *deleted);
void complete_tcp_msg (struct msg_from_udp *msg, struct msg_to_send *tcp_msg);
void print_msg(struct msg_to_send *tcp_msg, char *buffer);
queue is_subscribed(struct client *cl, char *topic, int *ok, int *sf);
queue send_msg(queue clients, struct msg_to_send tcp_msg);
queue add_msg_to_queue(queue clients, struct msg_to_send *tcp_msg);

#endif